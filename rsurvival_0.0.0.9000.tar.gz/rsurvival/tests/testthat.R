library(testthat)
library(rsurvival)

test_check("rsurvival")